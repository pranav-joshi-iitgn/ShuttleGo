from flask import Flask
from flask_mysqldb import MySQL
from authlib.integrations.flask_client import OAuth
import base64
import os

mysql = MySQL()
oauth = OAuth()

def create_app():
    app = Flask(__name__)

    # Add template filter for base64 encoding
    @app.template_filter('b64encode')
    def b64encode_filter(data):
        if data is None:
            return ''
        return base64.b64encode(data).decode('utf-8')

    app.config.from_pyfile('config.py')
    
    # Initialize MySQL
    mysql.init_app(app)
    
    # Initialize OAuth
    oauth.init_app(app)
    
    # Register Google OAuth
    oauth.register(
        name='google',
        server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
        client_id=app.config['GOOGLE_CLIENT_ID'],
        client_secret=app.config['GOOGLE_CLIENT_SECRET'],
        client_kwargs={'scope': 'openid email profile'}
    )
    
    # Register blueprints
    from app.auth.routes import auth
    from app.passenger.routes import passenger
    from app.driver.routes import driver
    
    app.register_blueprint(auth)
    app.register_blueprint(passenger)
    app.register_blueprint(driver)
    
    return app
