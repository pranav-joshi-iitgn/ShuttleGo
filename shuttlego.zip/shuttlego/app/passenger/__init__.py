# file : app/passenger/__init__.py

from flask import Blueprint

passenger = Blueprint('passenger', __name__, url_prefix='/passenger')

from . import routes
