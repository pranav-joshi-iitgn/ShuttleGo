# file : app/passenger/routes.py

from flask import render_template, request, redirect, url_for, session, flash, jsonify
from app import mysql
from . import passenger
import datetime

# Helper function to check if user is logged in as passenger
def passenger_login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session or session['user_type'] != 'passenger':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@passenger.route('/home')
@passenger_login_required
def home():
    cursor = mysql.connection.cursor()
    
    # Fetch all buses for the feedback form
    cursor.execute("SELECT BusID, BusRegistrationNumber FROM Bus")
    buses = cursor.fetchall()
    
    cursor.close()
    
    return render_template('passenger/home.html', buses=buses)


@passenger.route('/view_schedule')
@passenger_login_required
def view_schedule():
    cursor = mysql.connection.cursor()
    
    # Get all schedules using the SQL query from first.sql
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, b.BusRegistrationNumber, d.DriverName
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        JOIN Driver d ON s.DriverID = d.DriverID
        WHERE s.DepartureDay >= CURDATE()
        ORDER BY s.DepartureDay, s.StartTime, b.BusRegistrationNumber
    """)
    all_schedules = cursor.fetchall()
    
    # Get user's bookings
    cursor.execute("""
        SELECT b.JourneyID, b.BookingID, b.Seat
        FROM Bookings b
        WHERE b.UserID = %s
    """, [session['user_id']])
    bookings = cursor.fetchall()
    
    # Convert bookings to a dictionary for easier lookup
    user_bookings = {}
    for booking in bookings:
        user_bookings[booking['JourneyID']] = {
            'booking_id': booking['BookingID'],
            'seat': booking['Seat']
        }
    
    # Convert schedules to a dictionary
    schedules_dict = {}
    for schedule in all_schedules:
        journey_id = schedule['JourneyID']
        
        # Add booking status to the schedule
        schedule_with_status = dict(schedule)
        schedule_with_status['is_booked'] = journey_id in user_bookings
        if journey_id in user_bookings:
            schedule_with_status['booking_id'] = user_bookings[journey_id]['booking_id']
            schedule_with_status['seat'] = user_bookings[journey_id]['seat']
        
        # Group by date
        date_str = schedule['DepartureDay'].strftime('%Y-%m-%d')
        if date_str not in schedules_dict:
            schedules_dict[date_str] = []
        
        schedules_dict[date_str].append(schedule_with_status)
    
    # Convert back to a list, maintaining the sort order
    schedules_list = []
    for date in sorted(schedules_dict.keys()):
        for schedule in schedules_dict[date]:
            schedules_list.append(schedule)
    
    cursor.close()
    
    return render_template('passenger/schedule.html', schedules=schedules_list, user_bookings=user_bookings)

@passenger.route('/journey/<int:journey_id>')
@passenger_login_required
def journey(journey_id):
    cursor = mysql.connection.cursor()
    
    # Get journey details
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, r.IntermediateLocations,
               b.BusRegistrationNumber, b.Capacity, d.DriverName
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        JOIN Driver d ON s.DriverID = d.DriverID
        WHERE s.JourneyID = %s
    """, [journey_id])
    journey = cursor.fetchone()
    
    if not journey:
        flash('Journey not found', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    
    # Get all bookings for this journey
    cursor.execute("""
        SELECT b.BookingID, b.UserID, b.Seat, p.Name
        FROM Bookings b
        JOIN Passenger p ON b.UserID = p.PassengerID
        WHERE b.JourneyID = %s
    """, [journey_id])
    bookings = cursor.fetchall()
    
    # Create seat matrix
    seats = {}
    for i in range(1, journey['Capacity'] + 1):
        seats[i] = {'booked': False, 'user_id': None, 'name': None}
    
    for booking in bookings:
        seats[booking['Seat']] = {
            'booked': True,
            'user_id': booking['UserID'],
            'name': booking['Name'],
            'is_current_user': booking['UserID'] == session['user_id']
        }
    
    cursor.close()
    
    return render_template('passenger/journey.html', journey=journey, seats=seats)

@passenger.route('/book', methods=['POST'])
@passenger_login_required
def book():
    if request.method == 'POST':
        journey_id = request.form['journey_id']
        seat = request.form['seat']
        
        cursor = mysql.connection.cursor()
        
        # Use execute instead of callproc
        cursor.execute("CALL verify_new_booking(%s, %s, %s)", 
                      [journey_id, session['user_id'], seat])
        result = cursor.fetchone()
        
        # Get the first value regardless of the key
        valid = list(result.values())[0] if result else 0
        
        if valid == 1:
            cursor.execute("CALL create_new_booking(%s, %s, %s)", 
                         [journey_id, session['user_id'], seat])
            mysql.connection.commit()
            flash('Booking successful', 'success')
        else:
            flash('Booking failed. Seat may already be taken or journey is in the past.', 'danger')
        
        cursor.close()
        return redirect(url_for('passenger.view_schedule'))


@passenger.route('/cancel_booking', methods=['POST'])
@passenger_login_required
def cancel_booking():
    booking_id = request.form.get('booking_id')
    
    if not booking_id:
        flash('Invalid request', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    cursor = mysql.connection.cursor()
    
    # Call the stored procedure to cancel the booking
    cursor.callproc('cancel_booking', [booking_id])
    
    # Fetch the result from the stored procedure
    result = cursor.fetchone()
    
    # Consume any remaining result sets
    while cursor.nextset():
        pass  # This is crucial to clear out any pending results
    
    # Now it's safe to commit
    mysql.connection.commit()
    
    cursor.close()
    
    if result and result['val']:
        flash('Booking cancelled successfully', 'success')
    else:
        flash('Cancellation not allowed within 3 hours of departure', 'danger')
    
    return redirect(url_for('passenger.view_schedule'))

@passenger.route('/generate_ticket', methods=['POST'])
@passenger_login_required
def generate_ticket():

    booking_id = request.form.get('booking_id')
    
    if not booking_id:
        flash('Invalid request', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    
    cursor = mysql.connection.cursor()
    
    # Check if booking exists and belongs to user
    cursor.execute("""
        SELECT b.BookingID
        FROM Bookings b
        WHERE b.BookingID = %s AND b.UserID = %s
    """, (booking_id, session['user_id']))
    booking = cursor.fetchone()
    
    if not booking:
        flash('Booking not found', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    
    # Generate new ticket using stored procedure
    cursor.callproc('GenerateTicket', [booking_id])
    
    # Fetch the result from the stored procedure
    ticket_info = cursor.fetchone()
    
    # Consume any remaining result sets
    while cursor.nextset():
        pass
    
    mysql.connection.commit()
    
    # Get the newly created ticket
    cursor.execute("SELECT * FROM Tickets WHERE BookingID = %s", [booking_id])
    ticket = cursor.fetchone()
    
    cursor.close()
    
    if not ticket:
        flash('Failed to generate ticket', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    # return f"{existing_ticket}\n{ticket_info}"
    return render_template('passenger/ticket.html', ticket=ticket, ticket_info=ticket_info)


def can_cancel(departure_date, start_time):
    """Check if a booking can be canceled (more than 3 hours before departure)"""
    now = datetime.datetime.now()
    
    # Convert timedelta to time if needed
    if isinstance(start_time, datetime.timedelta):
        seconds = start_time.total_seconds()
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        seconds = int(seconds % 60)
        start_time = datetime.time(hours, minutes, seconds)
    
    departure = datetime.datetime.combine(departure_date, start_time)
    return (departure - now).total_seconds() > 10800  # 3 hours in seconds

@passenger.route('/booking_history')
@passenger_login_required
def booking_history():
    cursor = mysql.connection.cursor()
    
    # Execute the stored procedure using direct SQL execution
    cursor.execute("CALL GetUserBusUsage(%s)", [session['user_id']])
    
    # Fetch the results directly
    bookings = cursor.fetchall()
    
    # Get current date for comparison in template
    current_date = datetime.datetime.now().date()
    
    cursor.close()
    
    return render_template('passenger/booking_history.html', 
                          bookings=bookings, 
                          current_date=current_date,
                          can_cancel=can_cancel)

@passenger.route('/travel_history')
@passenger_login_required
def travel_history():
    cursor = mysql.connection.cursor()
    
    # Execute the GetUserBusUsage stored procedure
    cursor.execute("CALL GetUserBusUsage(%s)", [session['user_id']])
    
    # Fetch all travel records
    travels = cursor.fetchall()
    
    # Filter to only include journeys where the passenger actually boarded
    boarded_travels = [travel for travel in travels if travel['Boarded'] == 1]
    
    cursor.close()
    
    return render_template('passenger/travel_history.html', travels=boarded_travels)

@passenger.route('/penalties')
@passenger_login_required
def penalties():
    cursor = mysql.connection.cursor()
    
    cursor.execute("""
        SELECT p.PenaltyID, p.NumberOfMisses, p.PenaltyAmount, p.PenaltyDate
        FROM Penalty p
        WHERE p.UserID = %s
        ORDER BY p.PenaltyDate DESC
    """, [session['user_id']])
    
    penalties = cursor.fetchall()
    cursor.close()
    return render_template('passenger/penalties.html', penalties=penalties)


@passenger.route('/profile', methods=['GET', 'POST'])
@passenger_login_required
def profile():
    cursor = mysql.connection.cursor()
    
    # Fetch current user data
    cursor.execute("SELECT * FROM Passenger WHERE PassengerID = %s", [session['user_id']])
    user = cursor.fetchone()
    
    if request.method == 'POST':
        # Handle form submission for profile updates
        name = request.form.get('name')
        dob = request.form.get('dob')
        mobile = request.form.get('mobile')
        
        # Handle image upload if provided
        if 'image' in request.files and request.files['image'].filename:
            image = request.files['image'].read()
            # Update with image
            cursor.execute("""
                UPDATE Passenger 
                SET Name = %s, DateOfBirth = %s, MobileNumber = %s, Image = %s
                WHERE PassengerID = %s
            """, (name, dob, mobile, image, session['user_id']))
        else:
            # Update without changing image
            cursor.execute("""
                UPDATE Passenger 
                SET Name = %s, DateOfBirth = %s, MobileNumber = %s
                WHERE PassengerID = %s
            """, (name, dob, mobile, session['user_id']))
        
        mysql.connection.commit()
        
        # Update session variables
        session['name'] = name
        
        flash('Profile updated successfully', 'success')
        
        # Fetch updated user data
        cursor.execute("SELECT * FROM Passenger WHERE PassengerID = %s", [session['user_id']])
        user = cursor.fetchone()
    
    cursor.close()
    
    return render_template('passenger/profile.html', user=user)

@passenger.route('/feedback', methods=['POST'])
@passenger_login_required
def submit_feedback():
    if request.method == 'POST':
        # Get form data
        bus_id = request.form.get('bus_id')
        rating = request.form.get('rating')
        feedback_text = request.form.get('feedback_text')
        
        # Validate input
        if not bus_id or not rating or not feedback_text:
            flash('Please provide a bus, rating, and feedback text', 'danger')
            return redirect(url_for('passenger.home'))
        
        try:
            bus_id = int(bus_id)
            rating = int(rating)
            if rating < 1 or rating > 5:
                raise ValueError("Rating must be between 1 and 5")
        except ValueError:
            flash('Invalid input values', 'danger')
            return redirect(url_for('passenger.home'))
        
        # Get current date
        current_date = datetime.datetime.now().date()
        
        cursor = mysql.connection.cursor()
        
        # Verify bus exists
        cursor.execute("SELECT BusID FROM Bus WHERE BusID = %s", [bus_id])
        bus = cursor.fetchone()
        
        if not bus:
            flash('Selected bus does not exist', 'danger')
            cursor.close()
            return redirect(url_for('passenger.home'))
        
        # Check if user has already provided feedback for this bus
        cursor.execute("""
            SELECT FeedbackID FROM Feedback 
            WHERE UserID = %s AND BusID = %s
        """, (session['user_id'], bus_id))
        existing_feedback = cursor.fetchone()
        
        if existing_feedback:
            # Update existing feedback
            cursor.execute("""
                UPDATE Feedback 
                SET FeedbackText = %s, Rating = %s, FeedbackDate = %s
                WHERE FeedbackID = %s
            """, (feedback_text, rating, current_date, existing_feedback['FeedbackID']))
            feedback_action = "updated"
        else:
            # Insert new feedback
            cursor.execute("""
                INSERT INTO Feedback (UserID, BusID, FeedbackText, Rating, FeedbackDate)
                VALUES (%s, %s, %s, %s, %s)
            """, (session['user_id'], bus_id, feedback_text, rating, current_date))
            feedback_action = "submitted"
        
        mysql.connection.commit()
        cursor.close()
        
        flash(f'Thank you! Your feedback has been {feedback_action}.', 'success')
        return redirect(url_for('passenger.home'))

@passenger.route('/map/<int:journey_id>')
@passenger_login_required
def map(journey_id):
    cursor = mysql.connection.cursor()
    
    # Get journey details
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime,
               r.StartLocation, r.EndLocation, b.BusID, b.BusRegistrationNumber
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.JourneyID = %s
    """, [journey_id])
    
    journey = cursor.fetchone()
    
    if not journey:
        flash('Journey not found', 'danger')
        return redirect(url_for('passenger.view_schedule'))
    
    # Convert timedelta to time objects
    if isinstance(journey['StartTime'], datetime.timedelta):
        midnight = datetime.datetime.min
        journey['StartTime'] = (midnight + journey['StartTime']).time()
    
    if isinstance(journey['EndTime'], datetime.timedelta):
        midnight = datetime.datetime.min
        journey['EndTime'] = (midnight + journey['EndTime']).time()
    
    # Get current location
    cursor.execute("CALL GetLiveLocation(%s)", [journey['BusID']])
    location = cursor.fetchone()
    
    # Consume any remaining result sets
    while cursor.nextset():
        pass
    
    cursor.close()
    
    # Check if the journey is today and currently active
    current_date = datetime.datetime.now().date()
    current_time = datetime.datetime.now().time()
    
    journey_date = journey['DepartureDay']
    start_time = journey['StartTime']
    end_time = journey['EndTime']
    
    # Check if the journey is active today
    is_active = (journey_date == current_date and 
                start_time <= current_time <= end_time)
    
    # Check if the location data is recent (within the last 10 minutes)
    location_is_recent = False
    if location and location['LastUpdatedTime']:
        last_updated = location['LastUpdatedTime']
        if isinstance(last_updated, datetime.timedelta):
            midnight = datetime.datetime.min
            last_updated = (midnight + last_updated).time()
        
        now = datetime.datetime.now().time()
        now_seconds = now.hour * 3600 + now.minute * 60 + now.second
        last_updated_seconds = last_updated.hour * 3600 + last_updated.minute * 60 + last_updated.second
        
        # If last update was within 10 minutes (600 seconds)
        time_diff = abs(now_seconds - last_updated_seconds)
        if time_diff <= 600 or time_diff >= 86400 - 600:  # Handle day wraparound
            location_is_recent = True
    
    return render_template('passenger/map.html', 
                          journey=journey, 
                          location=location,
                          is_active=is_active,
                          location_is_recent=location_is_recent,
                          current_date=current_date,
                          current_time=current_time)
