from flask import Blueprint, render_template, redirect, url_for, session, flash, request
from app import mysql, oauth
import datetime

auth = Blueprint('auth', __name__)

@auth.route('/')
@auth.route('/login')
def login():
    return render_template('login.html')

@auth.route('/login_passenger', methods=['POST'])
def login_passenger():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM Passenger WHERE IITGNEmail = %s", [email])
        user = cursor.fetchone()
        cursor.close()
        
        if user:
            # In a real application, you would verify the password here
            # For now, we'll just log the user in
            session['logged_in'] = True
            session['user_type'] = 'passenger'
            session['user_id'] = user['PassengerID']
            session['name'] = user['Name']
            session['email'] = user['IITGNEmail']
            
            return redirect(url_for('passenger.home'))
        else:
            flash('Invalid email or password', 'danger')
            return redirect(url_for('auth.login'))

@auth.route('/google_login')
def google_login():
    redirect_uri = url_for('auth.google_callback', _external=True)
    return oauth.google.authorize_redirect(redirect_uri)

@auth.route('/google/callback')
def google_callback():
    token = oauth.google.authorize_access_token()
    user_info = token.get('userinfo')
    
    if user_info:
        email = user_info['email']
        
        # Check if the email is from IITGN domain
        if not email.endswith('@iitgn.ac.in'):
            flash('Please use your IITGN email address', 'danger')
            return redirect(url_for('auth.login'))
        
        cursor = mysql.connection.cursor()
        
        # Check if user exists
        cursor.execute("SELECT * FROM Passenger WHERE IITGNEmail = %s", [email])
        user = cursor.fetchone()
        
        if not user:
            # Register new user
            name = user_info.get('name', '')
            
            # Insert new user into database
            cursor.execute("""
                INSERT INTO Passenger (Name, IITGNEmail)
                VALUES (%s, %s)
            """, (name, email))
            mysql.connection.commit()
            
            # Get the newly created user
            cursor.execute("SELECT * FROM Passenger WHERE IITGNEmail = %s", [email])
            user = cursor.fetchone()
        
        cursor.close()
        
        # Set session variables
        session['logged_in'] = True
        session['user_type'] = 'passenger'
        session['user_id'] = user['PassengerID']
        session['name'] = user['Name']
        session['email'] = user['IITGNEmail']
        
        return redirect(url_for('passenger.home'))
    
    flash('Authentication failed', 'danger')
    return redirect(url_for('auth.login'))

@auth.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))

@auth.route('/login_driver', methods=['POST'])
def login_driver():
    if request.method == 'POST':
        driver_id = request.form['driver_id']
        password = request.form['password']
        
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM Driver WHERE DriverID = %s", [driver_id])
        driver = cursor.fetchone()
        cursor.close()
        
        if driver and driver.get('Password') == password:  # In production, use proper password hashing
            session['logged_in'] = True
            session['user_type'] = 'driver'
            session['user_id'] = driver['DriverID']
            session['name'] = driver['DriverName']
            
            return redirect(url_for('driver.home'))
        else:
            flash('Invalid driver ID or password', 'danger')
            return redirect(url_for('auth.login'))

