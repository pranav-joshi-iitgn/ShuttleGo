# file : app/driver/routes.py

from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from app import mysql
from functools import wraps
import datetime
from flask import current_app
from flask import g
from flask import session
import math

driver = Blueprint('driver', __name__, url_prefix='/driver')

# Helper function to check if user is logged in as driver
def driver_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session or session['user_type'] != 'driver':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function


@driver.route('/home')
@driver_login_required
def home():
    cursor = mysql.connection.cursor()
    
    # Get driver details
    cursor.execute("SELECT * FROM Driver WHERE DriverID = %s", [session['user_id']])
    driver_details = cursor.fetchone()
    
    # Get assigned journeys for today
    cursor.execute("""
        SELECT s.JourneyID, s.StartTime, s.EndTime, r.StartLocation, r.EndLocation, b.BusRegistrationNumber
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.DriverID = %s AND s.DepartureDay = CURDATE()
        ORDER BY s.StartTime
    """, [session['user_id']])
    today_journeys = cursor.fetchall()
    
    cursor.close()
    
    return render_template('driver/home.html', 
                          driver=driver_details, 
                          today_journeys=today_journeys)

@driver.route('/view_schedule', methods=['GET', 'POST'])
@driver_login_required
def view_schedule():
    cursor = mysql.connection.cursor()
    
    # Get all buses for the filter dropdown
    cursor.execute("""
        SELECT b.BusID, b.BusRegistrationNumber 
        FROM Bus b
        JOIN Schedule s ON b.BusID = s.BusID
        WHERE s.DriverID = %s
        GROUP BY b.BusID, b.BusRegistrationNumber
    """, [session['user_id']])
    buses = cursor.fetchall()
    
    # Check if a specific bus is selected
    selected_bus = request.args.get('bus_id', None)
    
    if selected_bus:
        # Use GetBusUsageByBus procedure for the selected bus
        cursor.execute("CALL GetBusUsageByBus(%s)", [selected_bus])
        bus_schedules = cursor.fetchall()
        
        # Consume any remaining result sets
        while cursor.nextset():
            pass
            
        # Natural join with other tables to get complete journey information
        cursor.execute("""
            SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
                   r.StartLocation, r.EndLocation, r.IntermediateLocations,
                   b.BusRegistrationNumber, b.BusID, d.DriverName
            FROM Schedule s
            JOIN Route r ON s.RouteID = r.RouteID
            JOIN Bus b ON s.BusID = b.BusID
            JOIN Driver d ON s.DriverID = d.DriverID
            WHERE s.DriverID = %s AND b.BusID = %s AND s.DepartureDay >= CURDATE()
            ORDER BY s.DepartureDay, s.StartTime
        """, (session['user_id'], selected_bus))
    else:
        # Get all schedules for the driver
        cursor.execute("""
            SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
                   r.StartLocation, r.EndLocation, r.IntermediateLocations,
                   b.BusRegistrationNumber, b.BusID, d.DriverName
            FROM Schedule s
            JOIN Route r ON s.RouteID = r.RouteID
            JOIN Bus b ON s.BusID = b.BusID
            JOIN Driver d ON s.DriverID = d.DriverID
            WHERE s.DriverID = %s AND s.DepartureDay >= CURDATE()
            ORDER BY s.DepartureDay, s.StartTime
        """, [session['user_id']])
    
    schedules = cursor.fetchall()
    
    # Group schedules by date for better display
    schedules_by_date = {}
    for schedule in schedules:
        date_str = schedule['DepartureDay'].strftime('%Y-%m-%d')
        if date_str not in schedules_by_date:
            schedules_by_date[date_str] = []
        schedules_by_date[date_str].append(schedule)
    
    cursor.close()
    
    return render_template('driver/schedule.html', 
                          schedules_by_date=schedules_by_date, 
                          buses=buses, 
                          selected_bus=selected_bus)


# @driver.route('/journey/<int:journey_id>')
# @driver_login_required
# def journey(journey_id):
#     cursor = mysql.connection.cursor()
    
#     # Verify journey belongs to driver
#     cursor.execute("""
#         SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
#                r.StartLocation, r.EndLocation, r.IntermediateLocations,
#                b.BusRegistrationNumber, b.Capacity
#         FROM Schedule s
#         JOIN Route r ON s.RouteID = r.RouteID
#         JOIN Bus b ON s.BusID = b.BusID
#         WHERE s.JourneyID = %s AND s.DriverID = %s
#     """, (journey_id, session['user_id']))
#     journey = cursor.fetchone()
    
#     if not journey:
#         flash('Journey not found or not assigned to you', 'danger')
#         return redirect(url_for('driver.home'))
    
#     # Get seat bookings
#     cursor.execute("""
#         SELECT b.BookingID, b.Seat, p.Name, p.IITGNEmail, p.MobileNumber, 
#                COALESCE(bd.Boarded, 0) as Boarded
#         FROM Bookings b
#         JOIN Passenger p ON b.UserID = p.PassengerID
#         LEFT JOIN Boarding bd ON b.BookingID = bd.BookingID
#         WHERE b.JourneyID = %s
#         ORDER BY b.Seat
#     """, [journey_id])
#     bookings = cursor.fetchall()
    
#     # Create seat matrix
#     seats = {}
#     for i in range(1, journey['Capacity'] + 1):
#         seats[i] = {'booked': False, 'passenger': None, 'boarded': False}
    
#     for booking in bookings:
#         seat_num = booking['Seat']
#         seats[seat_num] = {
#             'booked': True,
#             'booking_id': booking['BookingID'],
#             'passenger': booking,
#             'boarded': booking['Boarded'] == 1
#         }
    
#     cursor.close()
    
#     return render_template('driver/journey.html', 
#                           journey=journey, 
#                           seats=seats)


@driver.route('/journey/<int:journey_id>')
@driver_login_required
def journey(journey_id):
    cursor = mysql.connection.cursor()

    # Verify journey belongs to driver
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, r.IntermediateLocations,
               b.BusRegistrationNumber, b.Capacity
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.JourneyID = %s AND s.DriverID = %s
    """, (journey_id, session['user_id']))
    journey = cursor.fetchone()

    if not journey:
        flash('Journey not found or not assigned to you', 'danger')
        return redirect(url_for('driver.home'))

    # Get seat bookings
    cursor.execute("""
        SELECT b.BookingID, b.Seat, p.Name, p.IITGNEmail, p.MobileNumber, 
               COALESCE(bd.Boarded, 0) as Boarded
        FROM Bookings b
        JOIN Passenger p ON b.UserID = p.PassengerID
        LEFT JOIN Boarding bd ON b.BookingID = bd.BookingID
        WHERE b.JourneyID = %s
        ORDER BY b.Seat
    """, [journey_id])
    bookings = cursor.fetchall()

    start_time = journey['StartTime']
    end_time = journey['EndTime']

    # If start_time and end_time are timedelta objects
    #if isinstance(start_time, datetime.timedelta):
        # Convert timedelta to time by adding it to midnight
    print("trying to convert start_time")
    print("Before : ", start_time)
    midnight = datetime.datetime.min
    start_datetime = midnight + start_time
    start_time = start_datetime.time()
    print("After : ", start_time)

    #if isinstance(end_time, datetime.timedelta):
        # Convert timedelta to time by adding it to midnight
    print("trying to convert end_time")
    print("Before : ", end_time)
    midnight = datetime.datetime.min
    end_datetime = midnight + end_time
    end_time = end_datetime.time()
    print("After : ", end_time)


    # Create seat matrix
    seats = {}
    current_time = datetime.datetime.now()
    start_time = datetime.datetime.combine(journey['DepartureDay'], start_time)
    end_time = datetime.datetime.combine(journey['DepartureDay'], end_time)


    for i in range(1, math.ceil(journey['Capacity']/4)*4 + 1):
        seats[i] = {'booked': False, 'passenger': None, 'boarding_status': 'Available'}

    #seats = [{"booked": False, "passenger": None, "boarding_status": "Available"} for _ in range(journey['Capacity'] + 1)]

    for booking in bookings:
        seat_num = booking['Seat']
        if booking['Boarded'] == 1:
            boarding_status = 'Boarded'
        elif current_time < start_time:
            boarding_status = 'Not Boarded'
        elif current_time > end_time:
            boarding_status = 'Missed'
        else:
            boarding_status = 'Pending'

        seats[seat_num] = {
            'booked': True,
            'booking_id': booking['BookingID'],
            'passenger': booking,
            'boarding_status': boarding_status
        }

    cursor.close()

    #seats = [seats[i:i+4] for i in range(1, len(seats)+1, 4)]  # Group seats into rows of 4

    return render_template('driver/journey.html', 
                          journey=journey, 
                          seats=seats,
                          current_time=current_time)





@driver.route('/scan_qr')
@driver_login_required
def scan_qr():
    return render_template('driver/scan_qr.html')

@driver.route('/verify_ticket', methods=['POST'])
@driver_login_required
def verify_ticket():
    # Get form data with appropriate defaults
    booking_id = request.form.get('booking_id')
    decoded_date = request.form.get('decoded_date')
    decoded_time = request.form.get('decoded_time')
    source = request.form.get('source', 'manual_verification')  # Default to 'manual' if not provided

    # Validate required fields
    if not booking_id:
        flash('Booking ID is required.', 'danger')
        return redirect(url_for(f'driver.{source}'))

    cursor = mysql.connection.cursor()
    
    # Determine if we have a complete ticket ID or need to query for it
    if decoded_date and decoded_time:
        # We can construct the ticket ID from the provided information
        try:
            # Combine date and time into a timestamp

            combined_datetime = datetime.datetime.strptime(f"{decoded_date} {decoded_time}", '%Y-%m-%d %H:%M:%S')
            timestamp = int(combined_datetime.timestamp())
            print("prev : ", timestamp)
            # Adjust for timezone (IST to UTC)
            # local_dt = datetime.datetime.strptime(f"{decoded_date} {decoded_time}", '%Y-%m-%d %H:%M')
            # utc_dt = local_dt - datetime.timedelta(hours=5, minutes=30)
            # timestamp_n = int(utc_dt.timestamp())
            # print("new : ", timestamp_n)
            # Generate the ticket ID
            ticket_id = f"TICKET-{booking_id}-{timestamp}"
            print(f"Generated ticket ID: {ticket_id}")
        except ValueError as e:
            # Handle invalid date/time format 
            flash('Invalid date or time format. :' + repr(e), 'danger')
            return redirect(url_for(f'driver.{source}'))
    else:
        # We need to query the database to get the full ticket ID
        cursor.execute("""
            SELECT TicketID FROM Tickets 
            WHERE BookingID = %s
            ORDER BY CreatedAt DESC
            LIMIT 1
        """, [booking_id])
        
        ticket_result = cursor.fetchone()
        
        if not ticket_result:
            flash('No ticket found for this booking ID.', 'danger')
            return redirect(url_for(f'driver.{source}'))
            
        ticket_id = ticket_result['TicketID']

    # Call the VerifyTicket stored procedure
    cursor.execute("CALL VerifyTicket(%s)", [ticket_id])
    result = cursor.fetchone()
    print(result)
    # Consume any remaining result sets
    while cursor.nextset():
        pass

    mysql.connection.commit()
    
    # Process the verification result
    if result:
        status = result.get('Status')
        if status == 'Valid':
            flash('Ticket verified successfully. Passenger marked as boarded.', 'success')
            if decoded_date and decoded_time:flash(f'Ticket issued on: {decoded_date} at {decoded_time}', 'info')
        else:
            flash(status, 'danger')
    else:
        flash('Invalid result', 'danger')

    cursor.close()
    
    # Redirect back to the appropriate page
    return redirect(url_for(f'driver.{source}'))


@driver.route('/mark_boarding/<int:booking_id>', methods=['POST'])
@driver_login_required
def mark_boarding(booking_id):
    cursor = mysql.connection.cursor()
    
    # Verify booking belongs to a journey assigned to this driver
    # TODO : add this to SQL before deployment : `AND s.DepartureDay = CURDATE()`
    cursor.execute("""
        SELECT b.BookingID, b.JourneyID, s.DepartureDay
        FROM Bookings b
        JOIN Schedule s ON b.JourneyID = s.JourneyID
        WHERE b.BookingID = %s AND s.DriverID = %s
    """, (booking_id, session['user_id']))
    booking = cursor.fetchone()
    
    if not booking:
        flash('Booking not found or not for your journey today', 'danger')
        return redirect(url_for('driver.home'))
    
    # Call create_new_boarding procedure with boarded=TRUE
    cursor.execute("CALL create_new_boarding(%s, %s)", [booking_id, True])
    
    # Consume any remaining result sets
    while cursor.nextset():
        pass
    
    mysql.connection.commit()
    cursor.close()
    
    flash('Passenger marked as boarded successfully', 'success')
    return redirect(url_for('driver.manual_verification', journey_id=booking['JourneyID']))

@driver.route('/update_location/<int:journey_id>', methods=['GET', 'POST'])
@driver_login_required
def update_location(journey_id):
    cursor = mysql.connection.cursor()
    
    # Verify journey belongs to driver
    # TODO : add this to SQL before deployment : `AND s.DepartureDay = CURDATE()`
    cursor.execute("""
        SELECT s.BusID, b.BusRegistrationNumber, s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime
        FROM Schedule s
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.JourneyID = %s AND s.DriverID = %s
    """, (journey_id, session['user_id']))
    journey = cursor.fetchone()

    print(journey)
    
    if not journey:
        flash('Journey not found or not assigned to you today', 'danger')
        return redirect(url_for('driver.home'))
    
    if request.method == 'POST':
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        
        # Call UpdateLiveLocation procedure
        print("BusID : ", journey['BusID'])
        print("Latitude : ", latitude)
        print("Longitude : ", longitude)
        cursor.execute("CALL UpdateLiveLocation(%s, %s, %s)", 
                      [journey['BusID'], latitude, longitude])
        
        # Consume any remaining result sets
        while cursor.nextset():pass
            
        mysql.connection.commit()
        
        flash('Location updated successfully', 'success')
    
    # Get current location using GetLiveLocation procedure
    cursor.execute("CALL GetLiveLocation(%s)", [journey['BusID']])
    location = cursor.fetchone()
    
    # Consume any remaining result sets
    while cursor.nextset():pass
    
    cursor.close()


    return render_template('driver/map.html', 
                          journey=journey, 
                          location=location)

@driver.route('/manual_verification', methods=['GET', 'POST'])
@driver_login_required
def manual_verification():
    cursor = mysql.connection.cursor()
    
    # Fetch all journeys assigned to the driver for today
    # TODO: Before deployement, add this in the SQL : `AND s.DepartureDay = CURDATE()`
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, b.BusRegistrationNumber
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.DriverID = %s
        ORDER BY s.StartTime
    """, [session['user_id']])
    journeys = cursor.fetchall()
    
    # Get selected journey ID from query parameters
    selected_journey = request.args.get('journey_id', None)
    bookings = None
    journey_details = None
    
    if selected_journey:
        # Fetch details of the selected journey
        # TODO: Before deployement, add this in the SQL : `AND s.DepartureDay = CURDATE()`
        cursor.execute("""
            SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
                   r.StartLocation, r.EndLocation, b.BusRegistrationNumber
            FROM Schedule s
            JOIN Route r ON s.RouteID = r.RouteID
            JOIN Bus b ON s.BusID = b.BusID
            WHERE s.JourneyID = %s AND s.DriverID = %s
        """, (selected_journey, session['user_id']))
        journey_details = cursor.fetchone()
        
        if journey_details:
            # Fetch bookings for the selected journey

            cursor.execute("""
                WITH b as (select * from Bookings where JourneyID = %s)
                SELECT b.BookingID, b.Seat, p.Name, p.IITGNEmail, p.MobileNumber,
                       CASE
                            WHEN br.Boarded IS NOT NULL THEN br.Boarded
                            WHEN s.DepartureDay > CURDATE() OR (s.DepartureDay = CURDATE() AND s.StartTime > CURTIME()) THEN NULL
                            ELSE 0
                        END AS Boarded
                FROM b
                JOIN Passenger p ON b.UserID = p.PassengerID
                LEFT JOIN Boarding br ON b.BookingID = br.BookingID
                JOIN Schedule s ON b.JourneyID = s.JourneyID
                ORDER BY b.Seat ASC
            """, [selected_journey])
            bookings = cursor.fetchall()
    
    cursor.close()
    
    return render_template('driver/manual_verification.html', 
                           journeys=journeys, 
                           selected_journey=selected_journey,
                           journey_details=journey_details,
                           bookings=bookings)


# @driver.route('/mark_boarding', methods=['POST'])
# @driver_login_required
# def mark_boarding():
#     if request.method == 'POST':
#         booking_id = request.form['booking_id']
#         journey_id = request.form['journey_id']
        
#         cursor = mysql.connection.cursor()
        
#         # Check if booking exists
#         cursor.execute("""
#             SELECT b.BookingID, b.JourneyID, s.DepartureDay
#             FROM Bookings b
#             JOIN Schedule s ON b.JourneyID = s.JourneyID
#             WHERE b.BookingID = %s AND b.JourneyID = %s
#         """, (booking_id, journey_id))
#         booking = cursor.fetchone()
        
#         if not booking:
#             flash('Booking not found', 'danger')
#             return redirect(url_for('driver.manual_verification'))
        
#         # Mark as boarded
#         cursor.execute("""
#             INSERT INTO Boarding (BookingID, JourneyID, JourneyDate, Boarded)
#             VALUES (%s, %s, %s, TRUE)
#             ON DUPLICATE KEY UPDATE Boarded = TRUE
#         """, (booking_id, journey_id, booking['DepartureDay']))
#         mysql.connection.commit()
        
#         cursor.close()
        
#         flash('Passenger marked as boarded', 'success')
#         return redirect(url_for('driver.manual_verification'))

@driver.route('/get_bookings/<int:journey_id>')
@driver_login_required
def get_bookings(journey_id):
    cursor = mysql.connection.cursor()
    
    cursor.execute("""
        SELECT b.BookingID, b.Seat, p.Name, p.PassengerID,
               CASE WHEN bd.Boarded IS TRUE THEN 'Yes' 
                    WHEN bd.Boarded IS FALSE THEN 'No' 
                    ELSE 'Not Recorded' END as BoardingStatus
        FROM Bookings b
        JOIN Passenger p ON b.UserID = p.PassengerID
        LEFT JOIN Boarding bd ON b.BookingID = bd.BookingID
        WHERE b.JourneyID = %s
        ORDER BY b.Seat
    """, [journey_id])
    bookings = cursor.fetchall()
    
    cursor.close()
    
    return jsonify(bookings)

@driver.route('/map/<int:journey_id>')
@driver_login_required
def map(journey_id):
    cursor = mysql.connection.cursor()
    
    # Get journey details
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, b.BusID, b.BusRegistrationNumber
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.JourneyID = %s AND s.DriverID = %s
    """, (journey_id, session['user_id']))
    journey = cursor.fetchone()
    
    if not journey:
        flash('Journey not found or not assigned to you', 'danger')
        return redirect(url_for('driver.view_schedule'))
    
    # Get current location
    cursor.execute("""
        SELECT Latitude, Longitude, LastUpdatedTime
        FROM LiveLocation
        WHERE BusID = %s
        ORDER BY LastUpdatedTime DESC
        LIMIT 1
    """, [journey['BusID']])
    location = cursor.fetchone()
    
    cursor.close()
    
    return render_template('driver/map.html', journey=journey, location=location)

# @driver.route('/update_location', methods=['POST'])
# @driver_login_required
# def update_location():
#     if request.method == 'POST':
#         bus_id = request.form['bus_id']
#         latitude = request.form['latitude']
#         longitude = request.form['longitude']
        
#         cursor = mysql.connection.cursor()
        
#         # Check if there's already a location entry for this bus
#         cursor.execute("SELECT COUNT(*) as count FROM LiveLocation WHERE BusID = %s", [bus_id])
#         result = cursor.fetchone()
        
#         if result['count'] > 0:
#             # Update existing location
#             cursor.execute("""
#                 UPDATE LiveLocation
#                 SET Latitude = %s, Longitude = %s, LastUpdatedTime = NOW()
#                 WHERE BusID = %s
#             """, (latitude, longitude, bus_id))
#         else:
#             # Insert new location
#             cursor.execute("""
#                 INSERT INTO LiveLocation (BusID, Latitude, Longitude, LastUpdatedTime)
#                 VALUES (%s, %s, %s, NOW())
#             """, (bus_id, latitude, longitude))
        
#         mysql.connection.commit()
#         cursor.close()
        
#         return jsonify({'status': 'success'})

@driver.route('/feedback', methods=['GET', 'POST'])
@driver_login_required
def feedback():
    if request.method == 'POST':
        bus_id = request.form['bus_id']
        feedback_text = request.form['feedback_text']
        rating = request.form['rating']
        
        cursor = mysql.connection.cursor()
        
        cursor.execute("""
            INSERT INTO Feedback (UserID, BusID, FeedbackText, Rating, FeedbackDate)
            VALUES (%s, %s, %s, %s, CURDATE())
        """, (session['user_id'], bus_id, feedback_text, rating))
        mysql.connection.commit()
        
        cursor.close()
        
        flash('Feedback submitted successfully', 'success')
        return redirect(url_for('driver.home'))
    
    # Get list of buses for the dropdown
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT BusID, BusRegistrationNumber FROM Bus")
    buses = cursor.fetchall()
    cursor.close()
    
    return render_template('driver/feedback.html', buses=buses)
