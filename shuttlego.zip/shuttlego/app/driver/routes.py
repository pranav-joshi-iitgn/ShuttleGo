from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from app import mysql
from functools import wraps

driver = Blueprint('driver', __name__, url_prefix='/driver')

# Helper function to check if user is logged in as driver
def driver_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session or session['user_type'] != 'driver':
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@driver.route('/home')
@driver_login_required
def home():
    return render_template('driver/home.html')

@driver.route('/view_schedule')
@driver_login_required
def view_schedule():
    cursor = mysql.connection.cursor()
    
    # Get all schedules assigned to this driver
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, b.BusRegistrationNumber
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.DriverID = %s AND s.DepartureDay >= CURDATE()
        ORDER BY s.DepartureDay, s.StartTime
    """, [session['user_id']])
    schedules = cursor.fetchall()
    cursor.close()
    
    return render_template('driver/schedule.html', schedules=schedules)

@driver.route('/journey/<int:journey_id>')
@driver_login_required
def journey(journey_id):
    cursor = mysql.connection.cursor()
    
    # Get journey details
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, r.IntermediateLocations,
               b.BusRegistrationNumber, b.Capacity, b.BusID
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.JourneyID = %s AND s.DriverID = %s
    """, (journey_id, session['user_id']))
    journey = cursor.fetchone()
    
    if not journey:
        flash('Journey not found or not assigned to you', 'danger')
        return redirect(url_for('driver.view_schedule'))
    
    # Get all bookings for this journey
    cursor.execute("""
        SELECT b.BookingID, b.UserID, b.Seat, p.Name, 
               CASE WHEN bd.Boarded IS TRUE THEN 'Yes' 
                    WHEN bd.Boarded IS FALSE THEN 'No' 
                    ELSE 'Not Recorded' END as BoardingStatus
        FROM Bookings b
        JOIN Passenger p ON b.UserID = p.PassengerID
        LEFT JOIN Boarding bd ON b.BookingID = bd.BookingID
        WHERE b.JourneyID = %s
    """, [journey_id])
    bookings = cursor.fetchall()
    
    # Create seat matrix
    seats = {}
    for i in range(1, journey['Capacity'] + 1):
        seats[i] = {'booked': False, 'user_id': None, 'name': None, 'boarding_status': 'Not Booked'}
    
    for booking in bookings:
        seats[booking['Seat']] = {
            'booked': True,
            'user_id': booking['UserID'],
            'name': booking['Name'],
            'booking_id': booking['BookingID'],
            'boarding_status': booking['BoardingStatus']
        }
    
    cursor.close()
    
    return render_template('driver/journey.html', journey=journey, seats=seats)

@driver.route('/scan_qr')
@driver_login_required
def scan_qr():
    return render_template('driver/scan_qr.html')

@driver.route('/verify_ticket', methods=['POST'])
@driver_login_required
def verify_ticket():
    if request.method == 'POST':
        ticket_id = request.form['ticket_id']
        
        cursor = mysql.connection.cursor()
        
        # Call the stored procedure to verify the ticket
        cursor.callproc('VerifyTicket', [ticket_id])
        result = cursor.fetchone()
        mysql.connection.commit()
        
        cursor.close()
        
        if result['Status'] == 'Valid':
            flash('Ticket verified successfully', 'success')
        else:
            flash('Invalid or expired ticket', 'danger')
        
        return redirect(url_for('driver.scan_qr'))

@driver.route('/manual_verification')
@driver_login_required
def manual_verification():
    cursor = mysql.connection.cursor()
    
    # Get today's journeys for this driver
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, r.StartLocation, r.EndLocation
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        WHERE s.DriverID = %s AND s.DepartureDay = CURDATE()
        ORDER BY s.StartTime
    """, [session['user_id']])
    journeys = cursor.fetchall()
    
    cursor.close()
    
    return render_template('driver/manual_verification.html', journeys=journeys)

@driver.route('/mark_boarding', methods=['POST'])
@driver_login_required
def mark_boarding():
    if request.method == 'POST':
        booking_id = request.form['booking_id']
        journey_id = request.form['journey_id']
        
        cursor = mysql.connection.cursor()
        
        # Check if booking exists
        cursor.execute("""
            SELECT b.BookingID, b.JourneyID, s.DepartureDay
            FROM Bookings b
            JOIN Schedule s ON b.JourneyID = s.JourneyID
            WHERE b.BookingID = %s AND b.JourneyID = %s
        """, (booking_id, journey_id))
        booking = cursor.fetchone()
        
        if not booking:
            flash('Booking not found', 'danger')
            return redirect(url_for('driver.manual_verification'))
        
        # Mark as boarded
        cursor.execute("""
            INSERT INTO Boarding (BookingID, JourneyID, JourneyDate, Boarded)
            VALUES (%s, %s, %s, TRUE)
            ON DUPLICATE KEY UPDATE Boarded = TRUE
        """, (booking_id, journey_id, booking['DepartureDay']))
        mysql.connection.commit()
        
        cursor.close()
        
        flash('Passenger marked as boarded', 'success')
        return redirect(url_for('driver.manual_verification'))

@driver.route('/get_bookings/<int:journey_id>')
@driver_login_required
def get_bookings(journey_id):
    cursor = mysql.connection.cursor()
    
    cursor.execute("""
        SELECT b.BookingID, b.Seat, p.Name, p.PassengerID,
               CASE WHEN bd.Boarded IS TRUE THEN 'Yes' 
                    WHEN bd.Boarded IS FALSE THEN 'No' 
                    ELSE 'Not Recorded' END as BoardingStatus
        FROM Bookings b
        JOIN Passenger p ON b.UserID = p.PassengerID
        LEFT JOIN Boarding bd ON b.BookingID = bd.BookingID
        WHERE b.JourneyID = %s
        ORDER BY b.Seat
    """, [journey_id])
    bookings = cursor.fetchall()
    
    cursor.close()
    
    return jsonify(bookings)

@driver.route('/map/<int:journey_id>')
@driver_login_required
def map(journey_id):
    cursor = mysql.connection.cursor()
    
    # Get journey details
    cursor.execute("""
        SELECT s.JourneyID, s.DepartureDay, s.StartTime, s.EndTime, 
               r.StartLocation, r.EndLocation, b.BusID, b.BusRegistrationNumber
        FROM Schedule s
        JOIN Route r ON s.RouteID = r.RouteID
        JOIN Bus b ON s.BusID = b.BusID
        WHERE s.JourneyID = %s AND s.DriverID = %s
    """, (journey_id, session['user_id']))
    journey = cursor.fetchone()
    
    if not journey:
        flash('Journey not found or not assigned to you', 'danger')
        return redirect(url_for('driver.view_schedule'))
    
    # Get current location
    cursor.execute("""
        SELECT Latitude, Longitude, LastUpdatedTime
        FROM LiveLocation
        WHERE BusID = %s
        ORDER BY LastUpdatedTime DESC
        LIMIT 1
    """, [journey['BusID']])
    location = cursor.fetchone()
    
    cursor.close()
    
    return render_template('driver/map.html', journey=journey, location=location)

@driver.route('/update_location', methods=['POST'])
@driver_login_required
def update_location():
    if request.method == 'POST':
        bus_id = request.form['bus_id']
        latitude = request.form['latitude']
        longitude = request.form['longitude']
        
        cursor = mysql.connection.cursor()
        
        # Check if there's already a location entry for this bus
        cursor.execute("SELECT COUNT(*) as count FROM LiveLocation WHERE BusID = %s", [bus_id])
        result = cursor.fetchone()
        
        if result['count'] > 0:
            # Update existing location
            cursor.execute("""
                UPDATE LiveLocation
                SET Latitude = %s, Longitude = %s, LastUpdatedTime = NOW()
                WHERE BusID = %s
            """, (latitude, longitude, bus_id))
        else:
            # Insert new location
            cursor.execute("""
                INSERT INTO LiveLocation (BusID, Latitude, Longitude, LastUpdatedTime)
                VALUES (%s, %s, %s, NOW())
            """, (bus_id, latitude, longitude))
        
        mysql.connection.commit()
        cursor.close()
        
        return jsonify({'status': 'success'})

@driver.route('/feedback', methods=['GET', 'POST'])
@driver_login_required
def feedback():
    if request.method == 'POST':
        bus_id = request.form['bus_id']
        feedback_text = request.form['feedback_text']
        rating = request.form['rating']
        
        cursor = mysql.connection.cursor()
        
        cursor.execute("""
            INSERT INTO Feedback (UserID, BusID, FeedbackText, Rating, FeedbackDate)
            VALUES (%s, %s, %s, %s, CURDATE())
        """, (session['user_id'], bus_id, feedback_text, rating))
        mysql.connection.commit()
        
        cursor.close()
        
        flash('Feedback submitted successfully', 'success')
        return redirect(url_for('driver.home'))
    
    # Get list of buses for the dropdown
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT BusID, BusRegistrationNumber FROM Bus")
    buses = cursor.fetchall()
    cursor.close()
    
    return render_template('driver/feedback.html', buses=buses)
