from flask import Blueprint

driver = Blueprint('driver', __name__)

from . import routes
