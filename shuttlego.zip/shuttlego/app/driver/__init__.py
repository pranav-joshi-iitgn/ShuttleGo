# file : app/driver/__init__.py

from flask import Blueprint

driver = Blueprint('driver', __name__)

from . import routes
