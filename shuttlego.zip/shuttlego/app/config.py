import os
from datetime import timedelta

# Flask configuration
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key')
SESSION_TYPE = 'filesystem'
PERMANENT_SESSION_LIFETIME = timedelta(hours=5)

# MySQL configuration
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'A1b2c3d4.22110197'
MYSQL_DB = 'ShuttleGo'
MYSQL_CURSORCLASS = 'DictCursor'

# Google OAuth configuration
GOOGLE_CLIENT_ID = os.environ.get('GOOGLE_CLIENT_ID', "437838986953-l69sh4qvd65umqrchqckcgu4nqk8ek0n.apps.googleusercontent.com")
GOOGLE_CLIENT_SECRET = os.environ.get('GOOGLE_CLIENT_SECRET', "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")
